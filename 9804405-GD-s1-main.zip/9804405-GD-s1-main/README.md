# 6006CEM-MachineLearning-CW by Gurdeep Dhaliwal

The dataset used can be found at: https://www.kaggle.com/vicsuperman/prediction-of-music-genre/code

Here I attempt to make a machine learning model to predict music genre from the given dataset
